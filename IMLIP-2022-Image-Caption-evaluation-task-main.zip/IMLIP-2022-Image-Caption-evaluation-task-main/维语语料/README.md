## 该文件夹中包含藏语语料文件  
- 训练集：Uighur_train.xlsx
- 验证集：Uighur_val.xlsx
