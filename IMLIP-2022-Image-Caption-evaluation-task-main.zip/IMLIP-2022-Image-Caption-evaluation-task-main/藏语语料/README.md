## 该文件夹中包含藏语语料文件  
- 训练集：Tibetan_train.xlsx
- 验证集：Tibetan_val.xlsx
